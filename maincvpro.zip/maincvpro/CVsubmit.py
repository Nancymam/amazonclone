from tkinter import *
from docx import Document
from PIL import ImageTk, Image
import subprocess
import os

root=Tk()
root.geometry("850x475")
root.title("CV Generator")
filename=ImageTk.PhotoImage(Image.open("back4.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)
 
def submit2():

    file_name=ent.get()
    doc=Document()

    doc.save(file_name)

lbl=Label(root,text="CV Generator")
lbl.pack()

lbl0=Label(root,text="File Name:")
lbl0.pack(pady=15)

ent=Entry(root)
ent.pack()

lbl1=Label(root,text="Click Here For Submitting Your Data..")
lbl1.pack(pady=30)

btn=Button(root, text="Submit",padx=30,pady=10,)
btn.pack()

mainloop()