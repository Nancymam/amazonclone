from tkinter import *
import PIL
from PIL import Image,ImageTk
app = Tk()
app.geometry("400x500")
app["bg"]="pink"

frm=Frame(app,width=100,height=200)
frm.pack()

img=ImageTk.PhotoImage(Image.open("logo.jpg"))
lbl=Label(frm,image=img)
lbl.pack()

l = Label(app,text="hello")
l.pack()
l1 = Label(app,text="hii")
l1.pack()


mainloop()