from tkinter import *
from docx import Document
from docx.shared import Pt
from docx.shared import Inches
from docx.shared import RGBColor

def generate_cv():

    doc = Document()

    name = name_entry.get()
    name1  = doc.add_paragraph()
    run = name1.add_run(f"{name}")
    run.font.size = Pt(45)
    run.font.color.rgb = RGBColor(0, 0, 255 )

    table = doc.add_table(rows=1, cols=2)
    cell_0 = table.cell(0,0)
    table.autofit = False
    cell_0.width = Inches(5)
    
    bullet_point = u'\u2022'
    con = cell_0.add_paragraph("Contact")
    run = con.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    phone = phone_entry.get()
    phone  = cell_0.add_paragraph(f"{bullet_point} Mobile No. : {phone}")
    run = phone.runs[0]
    run.font.size = Pt(18)

    email = email_entry.get()
    email  = cell_0.add_paragraph(f"{bullet_point} E-mail : {email}")
    run = email.runs[0]
    run.font.size = Pt(18)

    personal = cell_0.add_paragraph("Personal Details ")
    run = personal.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    age = age_entry.get()
    age_1  = cell_0.add_paragraph(f"{bullet_point} Age : {age}")
    run = age_1.runs[0]
    run.font.size = Pt(18)

    gender = gender_entry.get()
    gender  = cell_0.add_paragraph(f"{bullet_point} Gender : {gender}")
    run = gender.runs[0]
    run.font.size = Pt(18)

    address = address_entry.get()
    address  = cell_0.add_paragraph(f"{bullet_point} Address : {address}")
    run = address.runs[0]
    run.font.size = Pt(18)
 
    skill = cell_0.add_paragraph("Skills")
    run = skill.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True
    
    skill_1 = skill_1_entry.get()
    skill_1  = cell_0.add_paragraph(f"{bullet_point} {skill_1}")
    run = skill_1.runs[0]
    run.font.size = Pt(18)
    run.font.bold = True

    skill_2 = skill_2_entry.get()
    skill_2  = cell_0.add_paragraph(f"{bullet_point} {skill_2}")
    run = skill_2.runs[0]
    run.font.size = Pt(18)
    run.font.bold = True

    skill_3 = skill_3_entry.get()
    skill_3  = cell_0.add_paragraph(f"{bullet_point} {skill_3}")
    run = skill_3.runs[0]
    run.font.size = Pt(18)
    run.font.bold = True

    skill_4 = skill_4_entry.get()
    
    skill_4  = cell_0.add_paragraph(f"{bullet_point} {skill_4}")
    run = skill_4.runs[0]
    run.font.size = Pt(18)
    run.font.bold = True

    education = cell_0.add_paragraph("Education")
    run = education.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    college =college_entry.get()
    year = year_entry.get()
    branch = branch_entry.get()
    cgpa = cgpa_entry.get()
    college  = cell_0.add_paragraph(f" {college} | {year} ")
    run = college.runs[0]
    run.font.size = Pt(16)
    run.font.bold = True
    branch  = cell_0.add_paragraph(f"{bullet_point} {branch} |  {cgpa}")
    run = branch.runs[0]
    run.font.size = Pt(16)

    college_1 = college_1_entry.get()
    year_1 = year_1_entry.get()
    branch_1 = branch_1_entry.get()
    cgpa_1 = cgpa_1_entry.get()
    college_1  = cell_0.add_paragraph(f" {college_1} | {year_1} ")
    run = college_1.runs[0]
    run.font.size = Pt(16)
    run.font.bold = True

    branch_1  = cell_0.add_paragraph(f"{bullet_point} {branch_1} |  {cgpa_1}")
    run = branch_1.runs[0]
    run.font.size = Pt(16)

    college_3 = college_2_entry.get()
    year_3 = year_2_entry.get()
    branch_3 = branch_2_entry.get()
    cgpa_3 = cgpa_2_entry.get()
    college_1  = cell_0.add_paragraph(f" {college_3} | {year_3} ")
    run = college_1.runs[0]
    run.font.size = Pt(16)
    run.font.bold = True
    branch_1  = cell_0.add_paragraph(f"{bullet_point} {branch_3} |  {cgpa_3}")
    run = branch_1.runs[0]
    run.font.size = Pt(16)
 
    cell_1 = table.cell(0,1)
    cell_1.width = Inches(5)

    project = cell_1.add_paragraph("Project")
    run = project.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    project_1 = project_1_entry.get()
    description_2 = description_2_entry.get()
    description_3 = description_3_entry.get()
    name_2  = cell_1.add_paragraph(f"Title : {project_1}")
    run = name_2.runs[0]
    run.font.size = Pt(20)
    run.font.bold = True
    expl_2 = cell_1.add_paragraph(f"{bullet_point} {description_2}")
    run = expl_2.runs[0]
    run.font.size = Pt(16)
    expl_3 = cell_1.add_paragraph(f"{bullet_point} {description_3}")
    run = expl_3.runs[0]
    run.font.size = Pt(16)

    project_2 = project_2_entry.get()
    description_4 = description_4_entry.get()
    description_5 = description_5_entry.get()
    name  = cell_1.add_paragraph()
    run = name.add_run(f"Title : {project_2}")
    run.font.size = Pt(20)
    run.font.bold = True
    expl = cell_1.add_paragraph(f"{bullet_point} {description_4}")
    run = expl.runs[0]
    run.font.size = Pt(16)
    expl_1= cell_1.add_paragraph(f"{bullet_point} {description_5}")
    run = expl_1.runs[0]
    run.font.size = Pt(16)

    project_3 = project_3_entry.get()
    description_6 = description_6_entry.get()
    description_7 = description_7_entry.get()
    name  = cell_1.add_paragraph()
    run = name.add_run(f"Title : {project_3}")
    run.font.size = Pt(20)
    run.font.bold = True
    expl = cell_1.add_paragraph(f"{bullet_point} {description_6}")
    run = expl.runs[0]
    run.font.size = Pt(16)
    expl_1= cell_1.add_paragraph(f"{bullet_point} {description_7}")
    run = expl_1.runs[0]
    run.font.size = Pt(16)

    exp = cell_1.add_paragraph("Experience")
    run = exp.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    company = company_entry.get()
    position = position_entry.get()
    duration = duration_entry.get()
    description_8 = description_8_entry.get()
    title  = cell_1.add_paragraph()
    run = title.add_run(f"{position}")
    run.font.size = Pt(18)
    run.font.bold = True
    details  = cell_1.add_paragraph(f" {company} | {duration}")
    run = details.runs[0]
    run.font.size = Pt(18)
    run.font.bold = True
    description = cell_1.add_paragraph(f"{bullet_point} {description_8}")
    run = description.runs[0]
    run.font.size = Pt(16)

    language = cell_1.add_paragraph("Languages : ")
    run = language.runs[0]
    run.font.size = Pt(26)
    run.font.color.rgb = RGBColor(0, 0, 255 )
    run.font.bold = True

    lang = lang_entry.get()
    lang_1 = lang_1_entry.get()
    college_2  = cell_1.add_paragraph(f"{bullet_point} First Language : {lang}")
    run = college_2.runs[0]
    run.font.size = Pt(18)  
    branch_2  = cell_1.add_paragraph(f"{bullet_point} Second Language : {lang_1}")
    run = branch_2.runs[0]
    run.font.size = Pt(18)
    
    output_file = output_entry.get() + ".docx"
    doc.save(output_file)
    result_label.config(text=f'CV generated successfully. Saved as {output_file}',font="sans-serif 12 bold")

screen = Tk()
screen.geometry("1520x830")
screen.maxsize(1520,830)
screen.title("CV Generator")
screen.config(background="gray")

lable_4=Label(screen,text = f" Cv Generator ",font = "arial 30 bold",bg="green",fg="cyan")
lable_4.place(x=660,y=5)

bullet = u'\u2022'
label_1 = Label(screen,text = f"{bullet} Personal Information",font = "arial 22 bold",bg="gray",fg="yellow")
label_1.place(x=20,y=40)
name =  Label(screen,text = "Name : ",font = "arial 16 bold",bg="gray",fg="yellow")
name.place(x=60,y=90)
name_entry = Entry(screen,font="arial 14 ",bg="white")
name_entry.place(x=150,y=90,height=26 )
phone =  Label(screen,text = "Phone : ",font = "arial 16 bold",bg="gray",fg="yellow")
phone.place(x=400,y=90)
phone_entry = Entry(screen,font="arial 14 ",bg="white")
phone_entry.place(x=495,y=90,height=26)
email =  Label(screen,text = "Email : ",font = "arial 16 bold",bg="gray",fg="yellow")
email.place(x=780,y=90)
email_entry = Entry(screen,font="arial 14 ",bg="white")
email_entry.place(x=870,y=90,height=26 )
address =  Label(screen,text = "Address : ",font = "arial 16 bold",bg="gray",fg="yellow")
address.place(x=1130,y=90)
address_entry = Entry(screen,font="arial 14 ",bg="white")
address_entry.place(x=1240,y=90,height=26 )
age =  Label(screen,text = "Age : ",font = "arial 16 bold",bg="gray",fg="yellow")
age.place(x=60,y=140)
age_entry = Entry(screen,font="arial 14 ",bg="white")
age_entry.place(x=150,y=140,height=26 )
gender =  Label(screen,text = "Gender : ",font = "arial 16 bold",bg="gray",fg="yellow")
gender.place(x=400,y=140)
gender_entry = Entry(screen,font="arial 14 ",bg="white")
gender_entry.place(x=495,y=140,height=26)
lang = Label(screen,text = "Language 1 : ",font = "arial 16 bold",bg="gray",fg="yellow")
lang.place(x=730,y=140)
lang_entry = Entry(screen,font="arial 14 ",bg="white")
lang_entry.place(x=870,y=140,height=26)
lang_1 = Label(screen,text = "Language 2 : ",font = "arial 16 bold",bg="gray",fg="yellow")
lang_1.place(x=1100,y=140)
lang_1_entry = Entry(screen,font="arial 14 ",bg="white")
lang_1_entry.place(x=1240,y=140,height=26)

label_2 = Label(screen,text = f"{bullet} Skills",font = "arial 22 bold",bg="gray",fg="yellow")
label_2.place(x=20,y=190)
skill_1 = Label(screen,text="Skill 1 :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
skill_1.place(x=60,y=230)
skill_1_entry = Entry(screen,font="arial 14")
skill_1_entry.place(x=150,y=230)
skill_2 = Label(screen,text="Skill 2 :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
skill_2.place(x=420,y=230)
skill_2_entry = Entry(screen,font="arial 14")
skill_2_entry.place(x=520,y=230)
skill_3 = Label(screen,text="Skill 3 : ",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
skill_3.place(x=780,y=230)
skill_3_entry = Entry(screen,font="arial 14")
skill_3_entry.place(x=870,y=230)
skill_4 = Label(screen,text="Skill 4 :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
skill_4.place(x=1130,y=230)
skill_4_entry = Entry(screen,font="arial 14")
skill_4_entry.place(x=1240,y=230)

label_3 = Label(screen,text = f"{bullet} Education",font = "arial 22 bold",bg="gray",fg="yellow")
label_3.place(x=20,y=280)

lbl = Label(screen,text="1.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=30,y=320)
college = Label(screen,text ="College/School :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
college.place(x=60,y=320)
college_entry = Entry(screen,font="arial 14")
college_entry.place(x=240,y=320,width=250)
year = Label(screen,text ="Year :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
year.place(x=60,y=360)
year_entry = Entry(screen,font="arial 14")
year_entry.place(x=240,y=360,width=250)
branch = Label(screen,text ="Branch/class :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
branch.place(x=60,y=400)
branch_entry = Entry(screen,font="arial 14")
branch_entry.place(x=240,y=400,width=250)
cgpa = Label(screen,text ="CGPA / %age :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
cgpa.place(x=60,y=440)
cgpa_entry = Entry(screen,font="arial 14")
cgpa_entry.place(x=240,y=440,width=250)

lbl = Label(screen,text="2.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=520,y=320)
college_1 = Label(screen,text ="College/School :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
college_1.place(x=550,y=320)
college_1_entry = Entry(screen,font="arial 14")
college_1_entry.place(x=730,y=320,width=250)
year_1 = Label(screen,text ="Year :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
year_1.place(x=550,y=360)
year_1_entry = Entry(screen,font="arial 14")
year_1_entry.place(x=730,y=360,width=250)
branch_1 = Label(screen,text ="Branch/class :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
branch_1.place(x=550,y=400)
branch_1_entry = Entry(screen,font="arial 14")
branch_1_entry.place(x=730,y=400,width=250)
cgpa_1 = Label(screen,text ="CGPA/ %age :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
cgpa_1.place(x=550,y=440)
cgpa_1_entry = Entry(screen,font="arial 14")
cgpa_1_entry.place(x=730,y=440,width=250)

lbl = Label(screen,text="3.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=1010,y=320)
college_2 = Label(screen,text ="College/School :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
college_2.place(x=1040,y=320)
college_2_entry = Entry(screen,font="arial 14")
college_2_entry.place(x=1215,y=320,width=250)
year_2 = Label(screen,text ="Year :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
year_2.place(x=1040,y=360)
year_2_entry = Entry(screen,font="arial 14")
year_2_entry.place(x=1215,y=360,width=250)
branch_2 = Label(screen,text ="Branch/class :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
branch_2.place(x=1040,y=400)
branch_2_entry = Entry(screen,font="arial 14")
branch_2_entry.place(x=1215,y=400,width=250)
cgpa_2 = Label(screen,text ="CGPA/ %age :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
cgpa_2.place(x=1040,y=440)
cgpa_2_entry = Entry(screen,font="arial 14")
cgpa_2_entry.place(x=1215,y=440,width=250)

label_15 = Label(screen,text = f"{bullet} Projects",font = "arial 22 bold",bg="gray",fg="yellow")
label_15.place(x=20,y=490)

lbl = Label(screen,text="1.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=30,y=530)
project_1 = Label(screen,text ="Project Name :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
project_1.place(x=60,y=530)
project_1_entry = Entry(screen,font="arial 14")
project_1_entry.place(x=240,y=530,width=250)

description_2 = Label(screen,text ="Description 1 :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_2.place(x=60,y=570)
description_2_entry = Entry(screen,font="arial 14")
description_2_entry.place(x=240,y=570,width=250)
description_3 = Label(screen,text ="Description 2 :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_3.place(x=60,y=610)
description_3_entry = Entry(screen,font="arial 14")
description_3_entry.place(x=240,y=610,width=250)

lbl = Label(screen,text="2.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=520,y=530)
project_2 = Label(screen,text ="Project Name :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
project_2.place(x=550,y=530)
project_2_entry = Entry(screen,font="arial 14")
project_2_entry.place(x=730,y=530,width=250)
description_4 = Label(screen,text ="Description 1  :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_4.place(x=550,y=570)
description_4_entry = Entry(screen,font="arial 14")
description_4_entry.place(x=730,y=570,width=250)
description_5 = Label(screen,text ="Description 2 :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_5.place(x=550,y=610)
description_5_entry = Entry(screen ,font="arial 14")
description_5_entry.place(x=730,y=610,width=250)

lbl = Label(screen,text="3.",font="sans-serif 16 bold",bg="gray",fg="red")
lbl.place(x=1010,y=530)
project_3 = Label(screen,text ="Project Name :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
project_3.place(x=1040,y=530)
project_3_entry = Entry(screen,font="arial 14")
project_3_entry.place(x=1215,y=530,width=250)
description_6 = Label(screen,text ="Description 1  :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_6.place(x=1040,y=570)
description_6_entry = Entry(screen,font="arial 14")
description_6_entry.place(x=1215,y=570,width=250)
description_7 = Label(screen,text ="Description 2 :",font="sans-serif 16 bold",bg="gray",fg="yellow" )
description_7.place(x=1040,y=610)
description_7_entry = Entry(screen ,font="arial 14")
description_7_entry.place(x=1215,y=610,width=250)

label_28 = Label(screen,text = f"{bullet} Experience ",font = "arial 22 bold",bg="gray",fg="yellow")
label_28.place(x=20,y=650)

company = Label(screen,text="Company :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
company.place(x=60,y=690)
company_entry = Entry(screen,font="arial 14")
company_entry.place(x=175,y=690)
position = Label(screen,text="Position :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
position.place(x=420,y=690)
position_entry = Entry(screen,font="arial 14")
position_entry.place(x=520,y=690)
duration = Label(screen,text="Duration : ",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
duration.place(x=765,y=690)
duration_entry = Entry(screen,font="arial 14")
duration_entry.place(x=870,y=690)
description_8 = Label(screen,text="Description :",justify=LEFT,font="sans-serif 16 bold",bg="gray",fg="yellow")
description_8.place(x=1110,y=690)
description_8_entry = Entry(screen,font="arial 14")
description_8_entry.place(x=1240,y=690)
output = Label(screen,text="Output File Name:",font="sans-serif 16 bold",bg="gray",fg="yellow")
output.place(x=550,y=730)
output_entry = Entry(screen,font="arial 14")
output_entry.place(x=750,y=730)

result_label = Label(screen, text="",fg="dark red",bg="gray")
result_label.place(x=610,y=760)

button = Button(screen, text="Generate CV",font="arial 18 bold",bg="yellow",fg="black",bd=8,command=generate_cv)
button.place(height=40)

mainloop()