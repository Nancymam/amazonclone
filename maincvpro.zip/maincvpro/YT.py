from pytube import YouTube
import os


url="https://youtu.be/TFEyiE5t9hc?si=lijNyXY4N1iuJj5l"
video=YouTube(url)

old_path=video.streams.filter(only_audio=True).first().download()

new_path=os.path.splitext(old_path)

os.rename(old_path,new_path[0]+".mp3")
