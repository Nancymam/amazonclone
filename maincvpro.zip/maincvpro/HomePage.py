from tkinter import *
from tkinter import PhotoImage
from PIL import Image ,ImageTk
import subprocess

import os 

root=Tk()
root.geometry("900x500")
root.maxsize(900,500)
root.title("All In One")
filename=ImageTk.PhotoImage(Image.open("b1.jpg"))
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def YT():
    subprocess.call(["python","YTHome.py"])

def CV():
    subprocess.call(["python","CVgen.py"])

def PDF():
    subprocess.call(["python","pdfcon.py"])

def appli():
    subprocess.call(["python","App.py"])

label=Label(root,text="ALL-IN-ONE",font="arial 16 bold",bg="black",fg="white",border="10")
label.place(x=380,y=30)

frm=Frame(root,width=100,height=200)
frm.place(x=230,y=120)
image=Image.open("logo.jpg")
res_img=image.resize((60,50))
img=ImageTk.PhotoImage(res_img)
lbl=Label(frm,image=img)
lbl.pack()

btn1=Button(root,text="YT Converter",command=YT,font="calibri 12 bold",foreground="black", bg="white",padx=38,pady=8)
btn1.place(x=180,y=180)

frm2=Frame(root,width=100,height=200)
frm2.place(x=610,y=120)
image2=Image.open("cv.jpg")
res_img2=image2.resize((60,50))
img2=ImageTk.PhotoImage(res_img2)
lbl2=Label(frm2,image=img2)
lbl2.pack()

btn2=Button(root,text="CV Generator",command=CV,font="calibri 12 bold",foreground="black",padx=38,pady=8)
btn2.place(x=550,y=180)

frm3=Frame(root,width=100,height=200)
frm3.place(x=230,y=300)
image3=Image.open("pdf.jpg")
res_img3=image3.resize((60,50))
img3=ImageTk.PhotoImage(res_img3)
lbl3=Label(frm3,image=img3)
lbl3.pack()

btn3=Button(root,text="PDF Converter",command=PDF,font="calibri 12 bold",foreground="black", bg="white",padx=35,pady=8)
btn3.place(x=180,y=360)

frm4=Frame(root,width=100,height=200)
frm4.place(x=610,y=300)
image4=Image.open("app.jpg")
res_img4=image4.resize((60,50))
img4=ImageTk.PhotoImage(res_img4)
lbl4=Label(frm4,image=img4)
lbl4.pack()

btn4=Button(root,text="Application Generator",command=appli,font="calibri 12 bold",foreground="black", bg="white",padx=7,pady=8)
btn4.place(x=550,y=360)

mainloop()