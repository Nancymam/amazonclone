from tkinter import *
from pytube import YouTube
from PIL import ImageTk, Image
import subprocess

import os

root=Tk()
root.geometry("700x440")
root.maxsize(700,440)
root.title("YouTube Converter")
filename=ImageTk.PhotoImage(Image.open("back.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def form1():
    subprocess.call(["python","cvgenerator.py"])

def back():
    subprocess.call(["python","HomePage.py"])

txt=Label(root,text="CV Generator")
txt.pack()

lbl1=Label(root,text="CV Generator",font="arial 20 bold")
lbl1.place(x=250,y=40)

btn=Button(root,text="Start",padx=50,pady=15,command=form1,font="calibri 10 bold")
btn.place(x=270,y=200)

btn2=Button(root,text="Back",padx=50,pady=15,command=back,font="calibri 10 bold")
btn2.place(x=270,y=270)

mainloop()