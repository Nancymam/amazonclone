from tkinter import *
import tkinter as tk
from PIL import ImageTk, Image
from pytube import YouTube
from pytube import Playlist
import subprocess

import os

root=Tk()
root.geometry("600x400")
root.maxsize(600,400)
root.title("YouTube Converter")
filename=ImageTk.PhotoImage(Image.open("photo1.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def Convrt1():
    entry12 = entry1.get()
    video=Playlist(entry12)

    for i in video.videos:
        i.streams.filter().first().download()

def mp3():
    subprocess.call(["python","YTdown3.py"])

def home():
    subprocess.call(["python","YTHome.py"])


txt=Label(root,text="YT Converter")
txt.place(x=260,y=40)

lbl2=Label(root,text="mP4 Converter",font="arial 20 bold")
lbl2.place(x=190,y=90)

lbl=Label(root, text="Enter URL",font="arial 16 bold")
lbl.place(x=140,y=160)
entry1=Entry(root,font="18")
entry1.place(x=255,y=165)

btn1=Button(root,text="Download",padx=25,pady=20, command=Convrt1)
btn1.place(x=240,y=260)

btn2=Button(root, text="mp3",padx=150,pady=8,command=mp3)
btn2.place(x=2)
btn3=Button(root, text="mp4",padx=150,pady=8)
btn3.place(x=300)

btn4=Button(root,text="Home",padx=288,pady=6,command=home)
btn4.place(y=370)

mainloop()
#https://youtube.com/playlist?list=PLxCzCOWd7aiHUUi6ZlansKbDw_cXut0El&si=7OhpnXZ-cDcQXvJh