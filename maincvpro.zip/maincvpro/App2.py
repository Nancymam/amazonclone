from tkinter import *
from docx import Document
from PIL import ImageTk, Image
import subprocess

import os

root=Tk()
root.geometry("850x475")
root.maxsize(850,475)
root.title("Application Generator")
filename=ImageTk.PhotoImage(Image.open("back7.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def back():
    subprocess.call(["python","App.py"])

def submit():
    name1=ent1.get()
    class1=ent2.get()
    rollno=ent3.get()
    school=ent4.get()
    place=ent5.get()
    days=ent7.get()
    file=ent6.get()
    date=ent8.get()
    doc=Document()
    doc.add_paragraph("To")
    doc.add_paragraph("The Principal")
    doc.add_paragraph(f"{school}")
    doc.add_paragraph(f"{place}.")
    doc.add_paragraph("SUBJECT: Sick Leave")
    doc.add_paragraph("Respected Sir,")
    doc.add_paragraph(f"With due respect, I beg to say that I am {name1} of class {class1} in your school. I am not feeling well today and also have some weakness. Hence I request you to please grant me {days}day leave.")
    doc.add_paragraph(f"I hope you will consider my application. I will definitely try to remain present after {days}day. ")
    doc.add_paragraph("I shall be thankful to you for this.")
    doc.add_paragraph("Yours obediently")
    doc.add_paragraph(f"Name:-{name1}")
    doc.add_paragraph(f"Class:-{class1}")
    doc.add_paragraph(f"Roll No.:-{rollno}")
    doc.add_paragraph({date})
    doc.save(file)

txt=Label(root,text="Sick Leave")
txt.pack()

lbl6=Label(root,text="Filename:",font="callibri 10 bold")
lbl6.place(x=530,y=10)
ent6=Entry(root)
ent6.place(x=601,y=11)
btn=Button(root,text="Submit",padx=30,pady=5,command=submit)
btn.place(x=727,y=6)

lbl=Label(root,text="FROM:",font="arial 10 underline")
lbl.place(x=50,y=60)

lbl1=Label(root,text="Name:")
lbl1.place(x=80,y=90)
ent1=Entry(root)
ent1.place(x=140,y=91)

lbl2=Label(root,text="Class:")
lbl2.place(x=80,y=120)
ent2=Entry(root)
ent2.place(x=140,y=121)

lbl3=Label(root,text="Roll No.:")
lbl3.place(x=80,y=150)
ent3=Entry(root)
ent3.place(x=140,y=151)

lbl=Label(root,text="TO:",font="arial 10 underline")
lbl.place(x=50,y=180)

lbl4=Label(root,text="School:")
lbl4.place(x=80,y=210)
ent4=Entry(root)
ent4.place(x=140,y=211)

lbl5=Label(root,text="Place:")
lbl5.place(x=80,y=240)
ent5=Entry(root)
ent5.place(x=140,y=241)

lbl7=Label(root,text="No. of Days:")
lbl7.place(x=50,y=300)
ent7=Entry(root)
ent7.place(x=140,y=301)

lbl8=Label(root,text="Date:")
lbl8.place(x=50,y=325)
ent8=Entry(root)
ent8.place(x=140,y=326)

btn2=Button(root,text="Back",padx=46,pady=10,command=back)
btn2.place(x=360,y=360)

mainloop()