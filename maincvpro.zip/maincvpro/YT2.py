from pytube import YouTube
import os

url="https://youtu.be/TFEyiE5t9hc?si=lijNyXY4N1iuJj5l"
video=YouTube(url)


old_path=video.streams.filter().get_highest_resolution()
new_path="C:\\videos"
old_path.download(new_path)

#os.rename(old_path,new_path[0]+".mp4")
print("Done")
# https://youtu.be/TFEyiE5t9hc?si=lijNyXY4N1iuJj5l