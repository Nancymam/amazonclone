from tkinter import *
import tkinter as tk
from tkinter import filedialog
from reportlab.pdfgen import canvas
from PIL import Image ,ImageTk
import subprocess

root=tk.Tk()
root.geometry("700x480")
root.maxsize(700,450)
root.title("PDF Convertor")
filename=ImageTk.PhotoImage(Image.open("back10.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def back():
    subprocess.call(["python","HomePage.py"])

def convert_to_pdf(content,output):
    pdf=canvas.Canvas(output)
    pdf.drawString(100,800,content)
    pdf.save()

def open_file():
    file_path=filedialog.askopenfilename(title="Select a Text File",filetypes=[("Text Files","*.txt")])
    if file_path:
        with open(file_path,'r')as file:
            content=file.read()
            ent1.delete(1.0,tk.END)
            ent1.insert(tk.END,content)

def convert_file():
    content=ent1.get(1.0,tk.END)
    output=filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF Files","*.pdf")])

    if output:
        convert_to_pdf(content,output)
        lbl.config(text="PDF Successfully Created....")



ent1=tk.Text(root,height=5,width=60)
ent1.pack(pady=10)

lbl=tk.Label(root,text="Text File to Pdf File Converter",fg='blue',font="arial 12 bold")
lbl.pack(pady=6)

opnbtn=tk.Button(root,text="Open File",padx=12,pady=3,command=open_file)
opnbtn.pack(pady=5)

cnvrt=tk.Button(root,text="Convert",padx=14,pady=3,command=convert_file)
cnvrt.pack(pady=10)

lbl=tk.Label(root,text="")
lbl.pack()

but1=Button(root,text="Home",command=back,padx=328,pady=7,bg="lightgreen",font="calibri 12 bold")
but1.place(x=2,y=415)

root.mainloop()