from tkinter import *
from docx import Document
from PIL import ImageTk, Image
import subprocess

import os

root=Tk()
root.geometry("850x475")
root.maxsize(850,475)
root.title("Application Generator")
filename=ImageTk.PhotoImage(Image.open("back7.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def app1():
    subprocess.call(["python","App1.py"])

def app2():
    subprocess.call(["python","App2.py"])

def app3():
    subprocess.call(["python","App3.py"])

def app4():
    subprocess.call(["python","App4.py"])

txt=Label(root,text="Application Generator",font="arial 10 bold")
txt.pack()

btn=Button(root,text="1. Urgent Piece Of Work",command=app1)
btn.place(x=50,y=50)

btn1=Button(root,text="2. Sick Leave",command=app2)
btn1.place(x=50,y=80)

btn2=Button(root, text="3. Application For School Leaving Certificate",command=app4)
btn2.place(x=50,y=110)

btn3=Button(root, text="4. Application For School Leaving Certificate After 12th.",command=app3)
btn3.place(x=50,y=140)

mainloop()