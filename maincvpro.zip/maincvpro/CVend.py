from tkinter import *
from tkinter import messagebox
import subprocess
from PIL import Image ,ImageTk

import os

root=Tk()
root.geometry("1360x900")
root.maxsize(1360,900)
root.title("CV Generator")

filename=ImageTk.PhotoImage(Image.open("b1.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)


def home():
    subprocess.call(["python","CVGen.py"])
    
txt=Label(root,text="CV Generator")
txt.pack()

lbl1=Label(root,text="Your CV is generated successfully....",font="calibri 13 bold",bg="black",fg="white")
lbl1.place(x=550,y=150)

btn=Button(root,text="Home",command=home,padx=40,pady=8)
btn.place(x=620,y=220)

mainloop()