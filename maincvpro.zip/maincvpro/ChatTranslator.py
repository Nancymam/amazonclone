import pyttsx3
from tkinter import *
from pytube import YouTube
from tkinter import PhotoImage
import subprocess

import os

root=Tk()
root.geometry("310x587")
root.title("CV Generator")
root["bg"]="pink"
engine=pyttsx3.init('sapi5')
voices=engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)
engine.setProperty('rate',150)

def speak():
    audio=e.get()
    engine.say(audio)
    engine.runAndWait()

def mainpg():
    subprocess.call(["python","mainpage.py"])

txt=Label(root,text="Voice Assistant")
txt.pack()

lbl1=Label(root,text="Voice Assistant",font="arial 16 bold")
lbl1.place(x=70,y=50)

e=Entry(root,width=19,font='arial 20 bold')
e.place(x=10,y=120)

btn=Button(root,text="Say",padx=20,pady=10,command=speak)
btn.place(x=120,y=200)

btn1=Button(root,text="Back",padx=25,pady=10,command=mainpg)
btn1.place(x=110,y=280)

btn1=Button(root,text="Reset",padx=25,pady=10)
btn1.place(x=110,y=335)

mainloop()