from tkinter import *
from pytube import YouTube
from PIL import Image ,ImageTk
import subprocess

import os

root=Tk()
root.geometry("600x400")
root.maxsize(600,400)
root.title("YouTube Converter")
filename=ImageTk.PhotoImage(Image.open("back1.jpg"))
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def mp3():
    subprocess.call(["python","YTdown.py"])

def mp4():
    subprocess.call(["python","YTdown2.py"])

def mp3Play():
    subprocess.call(["python","YTdown3.py"])

def mp4Play():
    subprocess.call(["python","YTdown4.py"])

txt=Label(root,text="YT Converter")
txt.pack()

lbl2=Label(root,text="YouTube Converter",font="arial 20 bold")
lbl2.place(x=160,y=25)

lbl3=Label(root,text="For single video:",font="arial 10 bold")
lbl3.place(x=240,y=150)
btn2=Button(root, text="mp3",padx=60,pady=13,command=mp3,font="arial 10 bold")
btn2.place(x=120,y=180)
btn3=Button(root, text="mp4",padx=60,pady=13,command=mp4,font="arial 10 bold")
btn3.place(x=320,y=180)

lbl3=Label(root,text="For multiple videos:",font="arial 10 bold")
lbl3.place(x=230,y=250)
btn2=Button(root, text="mp3",padx=60,pady=13,command=mp3Play,font="arial 10 bold")
btn2.place(x=120,y=280)
btn3=Button(root, text="mp4",padx=60,pady=13,command=mp4Play,font="arial 10 bold")
btn3.place(x=320,y=280)

mainloop()