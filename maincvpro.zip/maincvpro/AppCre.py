from tkinter import *
from docx import Document
from PIL import ImageTk, Image
import subprocess

import os

root=Tk()
root.geometry("850x475")
root.maxsize(850,475)
root.title("Application Generator")
filename=ImageTk.PhotoImage(Image.open("back7.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

mainloop()