from tkinter import *
from PIL import ImageTk, Image
from docx import Document
import subprocess
import os

root=Tk()
root.geometry("1360x900")
root.maxsize(1360,900)
root.title("CV Generator")

filename=ImageTk.PhotoImage(Image.open("b1.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def sub():
    name=entry01.get()
    mail=entry02.get()
    dob=entry03.get()
    phone=entry04.get()
    gender=entry05.get()    
    
    doc=Document()

    doc.add_heading(f"{name}")
    

def back():
    subprocess.call(["python","CVGen.py"])


lbl1=Label(root,text="CV Generator")
lbl1.pack()

frm=Frame(root,height=230,width=300)

lbl7=Label(root,text="_Personal Details_",font="calibri 14 bold")
lbl7.place(x=75,y=40)

lbl2=Label(root,text="Name:")
lbl2.place(x=10,y=80)
entry01=Entry(root,font="18")
entry01.place(x=90,y=80)

lbl3=Label(root,text="Email:")
lbl3.place(x=10,y=110)
entry02=Entry(root,font="18")
entry02.place(x=90,y=110)

lbl4=Label(root,text="DOB:")
lbl4.place(x=10,y=140)
entry03=Entry(root,font="18")
entry03.place(x=90,y=140)

lbl5=Label(root,text="Mobile No.:")
lbl5.place(x=10,y=170)
entry04=Entry(root,font="18")
entry04.place(x=90,y=170)

lbl6=Label(root,text="Gender:")
lbl6.place(x=10,y=200)
entry05=Entry(root,font="18")
entry05.place(x=90,y=200)

frm.place(x=5,y=30)

frm1=Frame(root,height=190,width=1345)

q1=Label(text="_Your Qualification_",font="calibri 14 bold")
q1.place(x=610,y=280)

q2=Label(root,text="10th:",font="arial 10 bold")
q2.place(x=10,y=320)

q3=Label(root,text="School:",)
q3.place(x=10,y=350)
qe1=Entry(root)
qe1.place(x=80,y=350)

q4=Label(root,text="Board:",)
q4.place(x=10,y=380)
qe2=Entry(root)
qe2.place(x=80,y=380)

q5=Label(root,text="Percentage:",)
q5.place(x=10,y=410)
qe3=Entry(root)
qe3.place(x=80,y=410)

q6=Label(root,text="12th:",font="arial 10 bold")
q6.place(x=370,y=320)

q7=Label(root,text="School:",)
q7.place(x=370,y=350)
qe4=Entry(root)
qe4.place(x=440,y=350)

q8=Label(root,text="Board:",)
q8.place(x=370,y=380)
qe5=Entry(root)
qe5.place(x=440,y=380)

q9=Label(root,text="Percentage:",)
q9.place(x=370,y=410)
qe6=Entry(root)
qe6.place(x=440,y=410)

q10=Label(root,text="Graduation:",font="arial 10 bold")
q10.place(x=730,y=320)

q7=Label(root,text="School:",)
q7.place(x=730,y=350)
qe4=Entry(root)
qe4.place(x=800,y=350)

q8=Label(root,text="Board:",)
q8.place(x=730,y=380)
qe5=Entry(root)
qe5.place(x=800,y=380)

q9=Label(root,text="Percentage:",)
q9.place(x=730,y=410)
qe6=Entry(root)
qe6.place(x=800,y=410)

q6=Label(root,text="Post Graduation:",font="arial 10 bold")
q6.place(x=1090,y=320)

q7=Label(root,text="School:",)
q7.place(x=1090,y=350)
qe4=Entry(root)
qe4.place(x=1160,y=350)

q8=Label(root,text="Board:",)
q8.place(x=1090,y=380)
qe5=Entry(root)
qe5.place(x=1160,y=380)

q9=Label(root,text="Percentage:",)
q9.place(x=1090,y=410)
qe6=Entry(root)
qe6.place(x=1160,y=410)

frm1.place(x=5,y=270)

frm2=Frame(root,height=100,width=500)

s1=Label(root,text="Strength:",font="bold")
s1.place(x=10,y=480)
se1=Entry(root)
se1.place(x=90,y=483)
se2=Entry(root)
se2.place(x=90,y=503)
se3=Entry(root)
se3.place(x=90,y=523)

s2=Label(root,text="Weakness:",font="bold")
s2.place(x=240,y=480)
se4=Entry(root)
se4.place(x=330,y=483)
se5=Entry(root)
se5.place(x=330,y=503)
se6=Entry(root)
se6.place(x=330,y=523)

frm2.place(x=5,y=470)

frm3=Frame(root,height=100,width=290)

p1=Label(root,text="Projects:",font="bold")
p1.place(x=520,y=480)
pe1=Entry(root)
pe1.place(x=600,y=480)
pe2=Entry(root)
pe2.place(x=600,y=510)

frm3.place(x=510,y=470)

label2=Label(root,text="Filename:",font="calibri 14 bold",fg="white",bg="black")
label2.place(x=20,y=590)
entrybox=Entry(root)
entrybox.place(x=120,y=595)

but1=Button(root,text="Submit",padx=40,pady=8,font="calibri 12 bold",command=sub)
but1.place(x=950,y=640)

but2=Button(root,text="Back",padx=50,pady=8,font="calibri 12 bold",command=back)
but2.place(x=1100,y=640)

mainloop()