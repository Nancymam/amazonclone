from tkinter import *

app = Tk()
def abc():
    new_window = Toplevel(app)
    lb = Label(new_window,text="hello")
    lb.pack()
    def bcd():
        newf = Toplevel(new_window)
        l = Label(newf,text="abc")
        l.pack() 
    bt2 = Button(new_window,text="next butn",command=bcd)
    bt2.pack()
def add():
    print("hii")

l = Label(app,text="hello")
l.pack()

btn = Button(app,text="next page",command=abc)
btn.pack()
mainloop()