from tkinter import *
from pytube import YouTube
from PIL import ImageTk, Image
import subprocess

import os

root=Tk()
root.geometry("600x400")
root.maxsize(600,400)
root.title("Application Generator")
filename=ImageTk.PhotoImage(Image.open("back6.jpg"),height=400,width=200)
background_label=Label(root,image=filename)
background_label.place(x=0,y=0,relwidth=1,relheight=1)

def mainpage():
    subprocess.call(["python","Appmain.py"])

def back():
    subprocess.call(["python","HomePage.py"])

txt=Label(root,text="Application Generator")
txt.pack()

lbl1=Label(root,text="Application Generator",font="arial 20 bold")
lbl1.place(x=150,y=40)

btn=Button(root,text="Start",padx=50,pady=15,command=mainpage)
btn.place(x=220,y=200)

btn2=Button(root,text="Back",padx=50,pady=15,command=back)
btn2.place(x=220,y=270)

mainloop()