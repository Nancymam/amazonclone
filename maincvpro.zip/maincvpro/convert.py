import inflect
p=inflect.engine()
a=p.number_to_words(99)
print(a)